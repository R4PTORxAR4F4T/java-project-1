package Contributers;
public class Contributers{
	String centerAlign= new String("\t\t\t\t\t\t\t\t\t\t\t\t  ");
	String centerAlign2= new String("\t\t\t\t\t\t\t\t ");
	public Contributers(){
		System.out.println(centerAlign2+"Econometry is a e-commerce system developed by CodeGrammer, a group of AIUB students.\n\n");
		System.out.println(centerAlign+"Contributers :\n");
		System.out.println(centerAlign+"Asif Hossain Neloy\n"+centerAlign+"CSE, 20-42996-1\n");
		System.out.println(centerAlign+"Ismail Hossain Rishad\n"+centerAlign+"CSE, 20-43002-1\n");
		System.out.println(centerAlign+"An Nazmus Sakib\n"+centerAlign+"CSE, 20-43056-1\n");
		System.out.println(centerAlign+"This project is guided by -\n");
		System.out.println(centerAlign+"MD. Nazmul Hossain\n"+centerAlign+"Faculty of CSE, AIUB\n");
	}
}