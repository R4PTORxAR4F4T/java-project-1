package Manual;
public class Manual{
	String centerAlign= new String("\t\t\t\t\t\t\t\t  ");

	public Manual(){
		System.out.println(centerAlign+"This is a e-commerce system developed by AIUB students using JAVA.\n\n");
		System.out.println(centerAlign+"E-conometry is basically a online application.\n"+centerAlign+"Here you can transfer your credits from yout bank account, can do online shopping,\n");
		System.out.println(centerAlign+"bill payments and if there is no internet, you can play a simple game through it.\n");
		System.out.println(centerAlign+"First you have to choose your access. You can access as a admin or a general user.");
		System.out.println(centerAlign+"When you are a admin, you can change certain things as like user balance, user password etc.\n");
		System.out.println(centerAlign+"First of all, a user have to register with certain amount of details. Then the user have to login.");
		System.out.println(centerAlign+"After finishing the primary options. A user is free to use the system.\n");
		System.out.println("\n"+centerAlign+"This is a simple project for advancement of learning in JAVA");
	}
}